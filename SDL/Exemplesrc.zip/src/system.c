#include "lib.h"

void SDL_ExitWithError(const char *text){

    SDL_Log("ERREUR : %s > ERREUR %s", text, SDL_GetError());
    SDL_Quit();
    exit(EXIT_FAILURE);
}

void SDL_VerifNull(SDL_Texture *t,char *message)
{
    if (t == NULL)  SDL_ExitWithError(message); 
}

int display_tabjeu(SDL_Renderer *r)
{
	if (SDL_SetRenderDrawColor(r,100,200,250,SDL_ALPHA_OPAQUE) != 0) SDL_ExitWithError("Color d'un rendu");
	for (int i = TMIN; i <= TMAX; i+=TCASE)
    {
        SDL_RenderDrawLine(r,i,TMIN,i,TMAX);
    }
    for (int i = TMIN; i <= TMAX; i+=TCASE)
    {
        SDL_RenderDrawLine(r,TMIN,i,TMAX,i);
    }
    return 1;
}

int display_textureP(SDL_Renderer *rendu,SDL_Texture *t,int x,int y)
{
    SDL_Rect position;
    position.x = x;
    position.y = y;
    SDL_QueryTexture(t, NULL, NULL, &position.w, &position.h);
    SDL_RenderCopy(rendu, t, NULL, &position);
    return 1;
}

int display_textureTab(SDL_Renderer *rendu,SDL_Texture *t,int x,int y)
{
    if (x <= NBCASE)
    {
        SDL_Rect position;
        position.x = (x*TCASE)+1;
        position.y = (y*TCASE)+1;
        SDL_QueryTexture(t, NULL, NULL, &position.w, &position.h);
        SDL_RenderCopy(rendu, t, NULL, &position);
    }
    return 1;
}

int vercase(Str_pos p, Str_pos m, int x, int y)
{
if(p.x+x == m.x && p.y+y == m.y) return 1;
else return 0;
}

SDL_bool buttonselect(Str_pos b,Str_pos m)
{
    if(m.x >= b.x && m.y >= b.y && m.x <= b.x+TCASE && m.y <= b.y+TCASE) return SDL_TRUE;
    else return SDL_FALSE;
}



int Calculx(int win,int ttab,int ttext)
{
    return ((win-ttab)-ttext)/2;
}

int SDL_TextCenter(int win,int ttab,int ttext)
{
    return TMAX+Calculx(win,ttab,ttext);
}

