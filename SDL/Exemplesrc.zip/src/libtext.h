#ifndef LIBTEXT_H_
#define LIBTEXT_H_

#define P2 "Distance"
#define P1 "Rapprocher"
#define P3 "Precision"
#define P4 "Corps a Corps"
#define P1_1 "Droit"
#define P2_1 "Diagonale"
#define P3_1 "Saut"




// message d'erreur

#define TextureText "texture text"


#endif