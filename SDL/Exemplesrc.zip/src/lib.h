#ifndef LIB_H_
#define LIB_H_

#include <SDL2/SDL_ttf.h>		//Inclusion des librairies
#include <SDL2/SDL_image.h>
#include <SDL2/SDL.h>
#include <stdio.h>
#include <stdlib.h>

#define TMIN 0			// Valeur min de la position du tableau
#define TMAX 500		// Valeur max de la position du tableau
#define TCASE 50		// Taille des cases du tableau
#define MTCASE TCASE/2  // La moitie d'une cases du tableau
#define NBCASE (TMAX/TCASE)-1

typedef struct Dimension
{
  int w;
  int h;
} Str_dim;

typedef struct Position
{
  int x;
  int y;
} Str_pos;


// system

SDL_bool buttonselect(Str_pos b,Str_pos m);
void SDL_ExitWithError(const char *text);
int display_tabjeu(SDL_Renderer *r);
int display_textureTab(SDL_Renderer *r,SDL_Texture *t, int x, int y);
int display_textureP(SDL_Renderer *r,SDL_Texture *t, int x, int y);
int vercase(Str_pos p, Str_pos m, int x, int y);
void SDL_VerifNull(SDL_Texture *t,char *message);

int Calculx(int win,int ttab,int ttext);
int SDL_TextCenter(int win,int ttab,int ttext);

// contents
int attackrap(SDL_Renderer *FondEcran, SDL_Texture *caseselect, Str_pos p, Str_pos m);
int attackdis(SDL_Renderer *FondEcran, SDL_Texture *caseselect, Str_pos p, Str_pos m);
int attackpre(SDL_Renderer *FondEcran, SDL_Texture *caseselect, Str_pos p, Str_pos m);
int attackcac(SDL_Renderer *FondEcran, SDL_Texture *caseselect, Str_pos p, Str_pos m);

int movedro(SDL_Renderer *rendu, SDL_Texture *texture, Str_pos p, Str_pos m);
int movedia(SDL_Renderer *rendu, SDL_Texture *texture, Str_pos p, Str_pos m);
int movesau(SDL_Renderer *rendu, SDL_Texture *texture, Str_pos p, Str_pos m);

#endif