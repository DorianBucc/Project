#include "lib.h"
#include "libtext.h"
/* gcc src/*.c -o bin/a -I include -L lib -lmingw32 -lSDL2main -lSDL2 -lSDL2_ttf  (-mwindows) */
int main(int argc, char **argv)
{
    /*Initialisation des variables*/


    Str_dim StrWindow = {1001,501};         // dimension de la fenetre                                                            
    SDL_Window *window = NULL;				      //Initialisation variable fenetre
    SDL_Renderer *FondEcran = NULL; 				//Initialisation variable rendu

    /*Initialisation de la SDL*/

    if(SDL_Init(SDL_INIT_VIDEO) != 0)   SDL_ExitWithError("Initialisation SDL_VIDEO");        //Initialisation de la SDL
    if(TTF_Init() == -1)                SDL_ExitWithError("Initialisation SDL_TTF");		  //Initialisation de la SDL pour les polices et textes

    /*Initialisation de la fenetre*/

    window = SDL_CreateWindow("JEU_DE_COMBAT", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, StrWindow.w, StrWindow.h, 0); //window prend pour valeur la fenetre initialiser
    if(window == NULL) SDL_ExitWithError("Initialisation SDL_WINDOW");		//Si la fenetre ne s'execute pas, renvoyer message d'erreur

    /*Initialisation du rendu*/

    FondEcran = SDL_CreateRenderer(window, -1, SDL_RENDERER_SOFTWARE);			//renderer prend pour valeur le rendu de la fenetre
    if(FondEcran == NULL) SDL_ExitWithError("Initialisation SDL_RENDERER");		//Si le rendu ne s'execute pas, renvoyer message d'erreur
    if(SDL_RenderClear(FondEcran) != 0) SDL_ExitWithError("Nettoyage SDL_RenderClear");	//Supprime le rendu de la fenetre 

    /*Initialisation des textures*/


    SDL_Texture *curseur = NULL, *pion1 = NULL, *pion2 = NULL, *pion3 = NULL, *caseselectattack = NULL, *caseselectmove = NULL;           // Initialisation des Texture

    curseur = SDL_CreateTexture(FondEcran, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, 50, 50);     // cureur en forme de croix
    SDL_SetRenderDrawColor(FondEcran,255,0,0,255);
    SDL_SetRenderTarget(FondEcran, curseur);
    SDL_RenderDrawLine(FondEcran,50,50,0,0);
    SDL_RenderDrawLine(FondEcran,0,50,50,0);
    SDL_SetRenderTarget(FondEcran, NULL);

    pion1 = SDL_CreateTexture(FondEcran, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, TCASE-2, TCASE-2);       // Texture du pion 1 triangle
    SDL_SetRenderDrawColor(FondEcran, 0, 0, 255, 255);
    SDL_SetRenderTarget(FondEcran, pion1);
    SDL_RenderDrawLine(FondEcran, 0, 50, 50, 50);
    SDL_RenderDrawLine(FondEcran, 50, 50, 25, 0);
    SDL_RenderDrawLine(FondEcran, 25, 0, 0, 50);
    SDL_SetRenderTarget(FondEcran, NULL);

    SDL_Rect rpion2 = {TCASE/4,TCASE/4,MTCASE,MTCASE};                          // Rectangle du pion 2 et 3

    pion2 = SDL_CreateTexture(FondEcran, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, TCASE-2, TCASE-2);   // Texture du pion 2 carré
    SDL_SetRenderDrawColor(FondEcran,30,100,200,255);
    SDL_SetRenderTarget(FondEcran, pion2);
    SDL_RenderDrawRect(FondEcran, &rpion2);
    SDL_SetRenderTarget(FondEcran, NULL);
    SDL_SetTextureBlendMode(pion2, SDL_BLENDMODE_BLEND);

    pion3 = SDL_CreateTexture(FondEcran, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, TCASE-2, TCASE-2);   // Texture du pion 3 carré de la meme taille que le pion 2
    SDL_SetRenderDrawColor(FondEcran,150,150,0,255);
    SDL_SetRenderTarget(FondEcran, pion3);
    SDL_RenderDrawRect(FondEcran, &rpion2);
    SDL_SetRenderTarget(FondEcran, NULL);
    SDL_SetTextureBlendMode(pion3, SDL_BLENDMODE_BLEND);

    caseselectattack = SDL_CreateTexture(FondEcran, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, TCASE-2, TCASE-2);
    SDL_SetRenderDrawColor(FondEcran,200,50,0,255);
    SDL_SetRenderTarget(FondEcran, caseselectattack);
    SDL_RenderClear(FondEcran);	
    SDL_SetRenderTarget(FondEcran, NULL);

    caseselectmove = SDL_CreateTexture(FondEcran, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, TCASE-2, TCASE-2);
    SDL_SetRenderDrawColor(FondEcran,0,50,200,255);
    SDL_SetRenderTarget(FondEcran, caseselectmove);
    SDL_RenderClear(FondEcran);	
    SDL_SetRenderTarget(FondEcran, NULL);

    if (curseur == NULL || pion1 == NULL || pion2 == NULL || pion3 == NULL)     SDL_ExitWithError("Texture Forme Geometrique"); // vérification des erreurs
    
    /* Police */


    TTF_Font *arial = NULL, *arialp = NULL;
    arial = TTF_OpenFont("C:/Windows/Fonts/ariblk.ttf",24);                         // arial
    arialp = TTF_OpenFont("C:/Windows/Fonts/ariblk.ttf",12);                        // arial petite
    if (arial == NULL || arial == NULL) SDL_ExitWithError("chargement police");     // verif

    SDL_Color rouge = {255,0,0,255};
    SDL_Color vert = {0,255,0,255};
    SDL_Color bleu = {0,0,255,255};


    /*Textuel*/


    SDL_Surface *surface = NULL;                                                // Surface temporaire qui permet de copier les texte dans une texture
    SDL_Texture *t1 = NULL, *p1 = NULL, *p2 = NULL, *p3 = NULL, *p4 = NULL;     // Texture des text
    SDL_Texture *t2 = NULL, *p1_1 = NULL, *p2_1 = NULL, *p3_1 = NULL;
////
    surface = TTF_RenderText_Solid(arial,"Les types d'attaques",rouge);
    t1 = SDL_CreateTextureFromSurface(FondEcran, surface);
    SDL_VerifNull(t1,TextureText);

    surface = TTF_RenderText_Solid(arialp,P1,vert);
    p1 = SDL_CreateTextureFromSurface(FondEcran, surface);
    SDL_VerifNull(p1,TextureText);

    surface = TTF_RenderText_Solid(arialp,P2,vert);
    p2 = SDL_CreateTextureFromSurface(FondEcran, surface);
    SDL_VerifNull(p2,TextureText);

    surface = TTF_RenderText_Solid(arialp,P3,vert);
    p3 = SDL_CreateTextureFromSurface(FondEcran, surface);
    SDL_VerifNull(p3,TextureText);

    surface = TTF_RenderText_Solid(arialp,P4,vert);
    p4 = SDL_CreateTextureFromSurface(FondEcran, surface);
    SDL_VerifNull(p4,TextureText);
////
    surface = TTF_RenderText_Solid(arial,"Les types de mouvement",rouge);
    t2 = SDL_CreateTextureFromSurface(FondEcran, surface);
    SDL_VerifNull(t2,TextureText);

    surface = TTF_RenderText_Solid(arialp,P1_1,vert);
    p1_1 = SDL_CreateTextureFromSurface(FondEcran, surface);
    SDL_VerifNull(p1_1,TextureText);

    surface = TTF_RenderText_Solid(arialp,P2_1,vert);
    p2_1 = SDL_CreateTextureFromSurface(FondEcran, surface);
    SDL_VerifNull(p2_1,TextureText);

    surface = TTF_RenderText_Solid(arialp,P3_1,vert);
    p3_1 = SDL_CreateTextureFromSurface(FondEcran, surface);
    SDL_VerifNull(p3_1,TextureText);
////
    if (surface == NULL)    SDL_ExitWithError("Surface text");
    SDL_FreeSurface(surface);


    /* Début du lancement du programme */


    SDL_bool prog_launch = SDL_TRUE;       // Booléen
    Str_pos mouse, mousetab, *tpion;                         // coordonné des pions
    int TourJoueur, GameTour = 0;
    int mode_jeu = -1;
    int a,b,c,d,e,f;
    int aa,bb,cc,dd,ee,ff;
    int ver = 0;

    int nombre_pion = 3;
    tpion = malloc(sizeof(Str_pos) * nombre_pion);

    tpion[1].x = 1;
    tpion[1].y = 1;
    tpion[2].x = 6;
    tpion[2].y = 6;

    SDL_bool selectcac = SDL_FALSE, selectpre = SDL_FALSE, selectdis = SDL_FALSE, selectrap = SDL_FALSE;
    SDL_bool selectdro = SDL_FALSE, selectdia = SDL_FALSE, selectsau = SDL_FALSE;
    

    /* Position bouton */
    int TCurseur;
    SDL_QueryTexture(curseur,NULL,NULL,&TCurseur,NULL);
    int PosTemp = (StrWindow.w-TMAX)/4;
    int PosRight = StrWindow.w-PosTemp-TCurseur;
    int PosLeft = PosTemp+TMAX;
    int PosMid = TMAX+(PosRight-PosLeft)+TCurseur/2;
    
        
    Str_pos Strb4 = {PosRight,300};
    Str_pos Strb3 = {PosRight,100};
    Str_pos Strb2 = {PosLeft,100};
    Str_pos Strb1 = {PosLeft,300};

    Str_pos Strb5 = {PosRight,100};
    Str_pos Strb6 = {PosLeft,100};
    Str_pos Strb7 = {PosMid,300};

    while(prog_launch)		                                                    //Tant que programme = LANCER
    {
        display_tabjeu(FondEcran);
        SDL_Event event;                                                        //Declaration de la variable(struct) event de type evenement
        while(SDL_PollEvent(&event)) 									        //Tant qu'il y a des evenements
        {
            switch(event.type)												    //Dans le cas où s'est un type d'evenement
            {
            case SDL_KEYDOWN:												    //Dans l'évenement d'une touche enfoncée alors ...
                switch (event.key.keysym.sym)				                        //Dans le cas d'une touche du clavier
                {
                    case SDLK_ESCAPE:								                //Dans le cas de la touche echap faire ...
                    prog_launch = SDL_FALSE;		                                //Le programme s'arrete
                    break;
                    case SDLK_a:
                    mode_jeu = 1;
                    break;
                    case SDLK_z:
                    mode_jeu = 2;
                    break;
                    case SDLK_h:
                    mode_jeu = -1;
                    break;
                    default:
                    break;
                }
            case SDL_MOUSEBUTTONDOWN:
                mouse.x = event.button.x;
                mouse.y = event.button.y;
                mousetab.x = mouse.x/TCASE;
                mousetab.y = mouse.y/TCASE;
                break;
            case SDL_QUIT:
                prog_launch = SDL_FALSE;
                break;
            default:
                break;
            }
        }


        if (mode_jeu == 1)
        {
            TourJoueur = GameTour%2;
            ver=0;

            if (selectcac && TourJoueur) ver = attackcac(FondEcran, caseselectattack, tpion[1], mousetab);          // Corps à corps
            else if (selectcac && !TourJoueur) ver = attackcac(FondEcran, caseselectattack, tpion[2], mousetab);    // Corps à corps
            
            else if (selectpre && TourJoueur) ver = attackpre(FondEcran, caseselectattack, tpion[1], mousetab);     // Precision
            else if (selectpre && !TourJoueur) ver = attackpre(FondEcran, caseselectattack, tpion[2], mousetab);    // Precision

            else if (selectdis && TourJoueur) ver = attackdis(FondEcran, caseselectattack, tpion[1], mousetab);     // Distance
            else if (selectdis && !TourJoueur) ver = attackdis(FondEcran, caseselectattack, tpion[2], mousetab);    // Distance
            
            else if (selectrap && TourJoueur) ver = attackrap(FondEcran, caseselectattack, tpion[1], mousetab);     // Rapproché
            else if (selectrap && !TourJoueur) ver = attackrap(FondEcran, caseselectattack, tpion[2], mousetab);    // Rapproché

            if(ver && (mousetab.x <= NBCASE && mousetab.y <= NBCASE) && (mousetab.x >= 0 && mousetab.y >= 0))
            { 
                if (TourJoueur){
                    if ((mousetab.x == tpion[2].x) && (mousetab.y == tpion[2].y))
                    {
                        printf("Vous avez touche\n");
                        GameTour++;
                    }
                }
                else
                {
                    if ((tpion[1].x == mousetab.x) && (tpion[1].y == mousetab.y))
                    {
                        printf("Vous avez touche\n");
                        GameTour++;
                    }
                }
            }   
        }

        else if (mode_jeu == 2)
        {
            TourJoueur = GameTour%2;
            ver=0;
            if (selectdro && TourJoueur) ver = movedro(FondEcran, caseselectmove, tpion[1], mousetab);
            else if (selectdro && !TourJoueur) ver = movedro(FondEcran, caseselectmove, tpion[2], mousetab);
            
            else if (selectdia && TourJoueur) ver = movedia(FondEcran, caseselectmove, tpion[1], mousetab);
            else if (selectdia && !TourJoueur) ver = movedia(FondEcran, caseselectmove, tpion[2], mousetab);
            
            else if (selectsau && TourJoueur) ver = movesau(FondEcran, caseselectmove, tpion[1], mousetab);
            else if (selectsau && !TourJoueur) ver = movesau(FondEcran, caseselectmove, tpion[2], mousetab);

            if(ver && (mousetab.x <= NBCASE && mousetab.y <= NBCASE) && (mousetab.x >= 0 && mousetab.y >= 0))
            { 
                if (TourJoueur){
                    tpion[1].x = mousetab.x;      //  idem
                    tpion[1].y = mousetab.y;      // A modifié à l'avenir
                    GameTour++;}
                else{
                    tpion[2].x = mousetab.x;      //  idem
                    tpion[2].y = mousetab.y;      // A modifié à l'avenir
                    GameTour++;}
            }
        }
        
        selectrap = buttonselect(Strb1,mouse);
        selectdis = buttonselect(Strb2,mouse);
        selectpre = buttonselect(Strb3,mouse);
        selectcac = buttonselect(Strb4,mouse);
////
        selectdro = buttonselect(Strb5,mouse);
        selectdia = buttonselect(Strb6,mouse);
        selectsau = buttonselect(Strb7,mouse);
        
        if(mode_jeu == 1)
        {
            SDL_QueryTexture(curseur,NULL,NULL,&aa,NULL);

            display_textureP(FondEcran,t1, 625, 25);

            SDL_QueryTexture(p2,NULL,NULL,&bb,NULL);
            display_textureP(FondEcran,curseur,Strb2.x,Strb2.y);
            display_textureP(FondEcran,p2, Strb2.x-(bb-aa)/2,Strb2.y-20);
            
            SDL_QueryTexture(p3,NULL,NULL,&bb,NULL);
            display_textureP(FondEcran,curseur,Strb3.x,Strb3.y);
            display_textureP(FondEcran,p3, Strb3.x-(bb-aa)/2,Strb3.y-20);
            
            SDL_QueryTexture(p1,NULL,NULL,&bb,NULL);
            display_textureP(FondEcran,curseur,Strb1.x,Strb1.y);
            display_textureP(FondEcran,p1,Strb1.x-(bb-aa)/2,Strb1.y-20);

            SDL_QueryTexture(p4,NULL,NULL,&bb,NULL);
            display_textureP(FondEcran,curseur,Strb4.x,Strb4.y);
            display_textureP(FondEcran,p4,Strb4.x-(bb-aa)/2,Strb4.y-20);
        }
        else if(mode_jeu == 2)
        {
            SDL_QueryTexture(curseur,NULL,NULL,&aa,NULL);

            SDL_QueryTexture(t2,NULL,NULL,&bb,NULL);
            display_textureP(FondEcran,t2, SDL_TextCenter(StrWindow.w,TMAX,bb), 25);

            
            SDL_QueryTexture(p1_1,NULL,NULL,&bb,NULL);
            display_textureP(FondEcran,curseur,Strb5.x,Strb5.y);
            display_textureP(FondEcran,p1_1, Strb5.x-Calculx(bb,aa,0), Strb5.y-25);

            SDL_QueryTexture(p2_1,NULL,NULL,&bb,NULL);
            display_textureP(FondEcran,curseur,Strb6.x,Strb6.y);
            display_textureP(FondEcran,p2_1, Strb6.x-Calculx(bb,aa,0), Strb6.y-25);

            SDL_QueryTexture(p3_1,NULL,NULL,&bb,NULL);
            display_textureP(FondEcran,curseur,Strb7.x,Strb7.y);
            display_textureP(FondEcran,p3_1, Strb7.x-Calculx(bb,aa,0), Strb7.y-25);
        }

        display_textureTab(FondEcran,pion2, tpion[1].x, tpion[1].y);
        display_textureTab(FondEcran,pion3, tpion[2].x, tpion[2].y);

        SDL_RenderPresent(FondEcran);
        SDL_SetRenderDrawColor(FondEcran,0,0,0,SDL_ALPHA_OPAQUE);       // Definir la couleur noir
        SDL_RenderClear(FondEcran);										//définir tous les pixels du renderer à la couleur
    }


    /*Fermeture de la fenetre SDL*/
    
    SDL_DestroyTexture(p3_1);
    SDL_DestroyTexture(p2_1);
    SDL_DestroyTexture(p1_1);
    SDL_DestroyTexture(t2);
    SDL_DestroyTexture(p4);
    SDL_DestroyTexture(p3);
    SDL_DestroyTexture(p2);
    SDL_DestroyTexture(p1);
    SDL_DestroyTexture(t1);
    SDL_DestroyTexture(pion3);
    SDL_DestroyTexture(pion2);
    SDL_DestroyTexture(pion1);
    SDL_DestroyTexture(curseur);
    SDL_DestroyTexture(caseselectattack);
    SDL_DestroyRenderer(FondEcran);	    //Destruction du rendu
    SDL_DestroyWindow(window);		    //Destruction de la fenetre
    SDL_Quit();						    //Fermeture de la SDL

    return EXIT_SUCCESS;	//Retour si fermeture bein executee

}