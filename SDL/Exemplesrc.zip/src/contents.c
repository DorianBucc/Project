#include "lib.h"

int attackrap(SDL_Renderer *rendu, SDL_Texture *texture, Str_pos p, Str_pos m)
{
    int ver = 0;
    display_textureTab(rendu, texture, p.x+1, p.y+1);
    display_textureTab(rendu, texture, p.x+1, p.y);
    display_textureTab(rendu, texture, p.x, p.y+1);
    display_textureTab(rendu, texture, p.x+1, p.y-1);
    display_textureTab(rendu, texture, p.x-1, p.y+1);
    display_textureTab(rendu, texture, p.x-1, p.y);
    display_textureTab(rendu, texture, p.x, p.y-1);
    display_textureTab(rendu, texture, p.x-1, p.y-1);
    if(!ver) ver = vercase(p, m, 1, 1);
    if(!ver) ver = vercase(p, m, 1, 0);
    if(!ver) ver = vercase(p, m, 0, 1);
    if(!ver) ver = vercase(p, m,-1, 1);
    if(!ver) ver = vercase(p, m, 1,-1);
    if(!ver) ver = vercase(p, m,-1, 0);
    if(!ver) ver = vercase(p, m, 0,-1);
    if(!ver) ver = vercase(p, m,-1,-1);
    return ver;
}

int attackdis(SDL_Renderer *rendu, SDL_Texture *texture, Str_pos p, Str_pos m)
{
    int ver = 0;
    display_textureTab(rendu, texture, p.x+2, p.y);
    display_textureTab(rendu, texture, p.x, p.y+2);
    display_textureTab(rendu, texture, p.x-2, p.y);
    display_textureTab(rendu, texture, p.x, p.y-2);
    if(!ver) ver = vercase(p, m, 2, 0);
    if(!ver) ver = vercase(p, m, 0, 2);
    if(!ver) ver = vercase(p, m,-2, 0);
    if(!ver) ver = vercase(p, m, 0,-2);
    return ver;
}

int attackpre(SDL_Renderer *rendu, SDL_Texture *texture, Str_pos p, Str_pos m)
{
    int ver = 0;
    display_textureTab(rendu, texture, p.x+2, p.y-1);
    display_textureTab(rendu, texture, p.x+1, p.y+2);
    display_textureTab(rendu, texture, p.x-2, p.y+1);
    display_textureTab(rendu, texture, p.x-1, p.y-2);
    if(!ver) ver = vercase(p, m, 2,-1);
    if(!ver) ver = vercase(p, m, 1, 2);
    if(!ver) ver = vercase(p, m,-2, 1);
    if(!ver) ver = vercase(p, m,-1,-2);
    return ver;
}

int attackcac(SDL_Renderer *rendu, SDL_Texture *texture, Str_pos p, Str_pos m)
{
    int ver = 0;
    display_textureTab(rendu, texture, p.x+1, p.y);
    display_textureTab(rendu, texture, p.x, p.y+1);
    display_textureTab(rendu, texture, p.x-1, p.y);
    display_textureTab(rendu, texture, p.x, p.y-1);
    if(!ver) ver = vercase(p, m, 1, 0);
    if(!ver) ver = vercase(p, m, 0, 1);
    if(!ver) ver = vercase(p, m,-1, 0);
    if(!ver) ver = vercase(p, m, 0,-1);
    return ver;
}

#define distdro 5
int movedro(SDL_Renderer *rendu, SDL_Texture *texture, Str_pos p, Str_pos m)
{
    int ver = 0,i;
    for (i = 1; i < distdro; i++) display_textureTab(rendu, texture, p.x+i, p.y);
    for (i = 1; i < distdro; i++) display_textureTab(rendu, texture, p.x-i, p.y);
    for (i = 1; i < distdro; i++) display_textureTab(rendu, texture, p.x, p.y+i);
    for (i = 1; i < distdro; i++) display_textureTab(rendu, texture, p.x, p.y-i);
    i = -distdro;
    while (!ver && i < distdro){  ver = vercase(p, m, i, 0); i++;}
    i = -distdro;
    if (!ver)   while (!ver && i < distdro){  ver = vercase(p, m, 0, i); i++;}
    return ver;
}

#define distdia 4
int movedia(SDL_Renderer *rendu, SDL_Texture *texture, Str_pos p, Str_pos m)
{
    int ver = 0,i;
    for (i = -distdia; i < distdia; i++) display_textureTab(rendu, texture, p.x+i, p.y+i);
    for (i = -distdia; i < distdia; i++) display_textureTab(rendu, texture, p.x+i*(-1), p.y+i);
    i = -distdia;
    while (!ver && i < distdia){  ver = vercase(p, m, i, i); i++;}
    i = -distdia;
    if (!ver)   while (!ver && i < distdia){  ver = vercase(p, m, i*(-1), i); i++;}
}

#define distsau 3
int movesau(SDL_Renderer *rendu, SDL_Texture *texture, Str_pos p, Str_pos m)
{
    int ver = 0,i;
    for (i = -distsau+1; i < distsau; i++) {
        display_textureTab(rendu, texture, p.x+i, p.y+2);
        display_textureTab(rendu, texture, p.x+i, p.y-2);
        display_textureTab(rendu, texture, p.x+2, p.y+i);
        display_textureTab(rendu, texture, p.x-2, p.y+i);
    }
}