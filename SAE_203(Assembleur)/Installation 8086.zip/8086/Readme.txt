Pour Windows seulement (autre il faudra adapter)

Pour configurer il faut:

	installer DOSBox (un lien : https://sourceforge.net/projects/dosbox/files/dosbox/0.74-3/DOSBox0.74-3-win32-installer.exe/download )
	installer Geany (un lien : https://www.clubic.com/telechargement-en-cours/430533-0-geany.html )

	Décompresser le fichier "8086.zip"
	Deplacer le dossier "8086" dans la racine du disque principale ( exemple C:\8086 )


Dans Geany à complèter dans "Set Build Command" ou "Définir les commandes de construction", recopier la ligne complète dans "Command"

	Pour Compile : 
"C:\Program Files (x86)\DOSBox-0.74-3\DOSBox.exe" -noconsole -userconf -c "mount c C:\8086" -c "C:" -c "masm %f" -c "@pause" -c "exit"

	Pour Lier (EXE) : 
"C:\Program Files (x86)\DOSBox-0.74-3\DOSBox.exe" -noconsole -userconf -c "mount c C:\8086" -c "C:" -c "link %e.OBJ" -c "@pause" -c "exit"

	Pour Executer : 
@"C:\Program Files (x86)\DOSBox-0.74-3\DOSBox.exe" -noconsole -userconf -c "mount c C:\8086" -c "C:" -c "%e" -c "@pause" -c "exit"


* Il y a deux exemples pour tester si l'installation c'est bien passer
* Tous les fichiers .asm doivent se trouver dans le dossier 8086 ( Un petit raccourci vers le dossier peut être pratique )

* Aucun .COM ne fonctionne correctement seulement les .EXE